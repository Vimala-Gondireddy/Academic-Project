document.addEventListener('DOMContentLoaded', function() {
    var ctx = document.getElementById('comparisonChart').getContext('2d');
    var comparisonChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Accuracy', 'Precision', 'Recall', 'F1 Score'],
            datasets: [{
                label: 'Model 1',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1,
                data: [{{ model1_accuracy }}, {{ model1_precision }}, {{ model1_recall }}, {{ model1_f1 }}]
            }, {
                label: 'Model 2',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                data: [{{ model2_accuracy }}, {{ model2_precision }}, {{ model2_recall }}, {{ model2_f1 }}]
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
