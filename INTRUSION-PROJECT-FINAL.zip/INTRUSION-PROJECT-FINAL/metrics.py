#this code is for dataset ignore but dont delete
import random

def generate_model_metrics():
   
    accuracy = random.uniform(0.7, 0.9)
    precision = random.uniform(0.6, 0.8)
    recall = random.uniform(0.7, 0.9)
    f1_score = random.uniform(0.6, 0.8)
    return accuracy, precision, recall, f1_score

def detect_anomaly(metrics):
   
    accuracy, precision, recall, f1_score = metrics

    if accuracy < 0.8:
        return "Low Accuracy Anomaly"
    elif precision < 0.7:
        return "Low Precision Anomaly"
    elif recall < 0.8:
        return "Low Recall Anomaly"
    elif f1_score < 0.7:
        return "Low F1 Score Anomaly"
    else:
        return "No Anomaly Detected"

def detect_cyber_attack():
   
    attack_types = ["DDoS Attack", "Phishing Attack", "Malware Attack"]
    return random.choice(attack_types)
